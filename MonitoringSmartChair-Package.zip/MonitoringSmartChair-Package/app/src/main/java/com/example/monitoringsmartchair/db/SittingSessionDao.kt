// db/SittingSessionDao.kt
package com.example.monitoringsmartchair.db

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface SittingSessionDao {

    @Query("SELECT * FROM sitting_sessions ORDER BY date DESC LIMIT 7")
    fun getLast7Days(): LiveData<List<SittingSession>>

    @Query("SELECT * FROM sitting_sessions WHERE date = :date LIMIT 1")
    suspend fun getByDate(date: String): SittingSession?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(session: SittingSession)

    @Update
    suspend fun update(session: SittingSession)

    // ← TAMBAH: ambil semua entri hari ini (untuk live update durasi)
    @Query("SELECT * FROM sitting_sessions WHERE date = :date ORDER BY timestamp DESC")
    fun getByDateLive(date: String): LiveData<List<SittingSession>>

    // ← TAMBAH: hapus data lebih dari 7 hari (panggil saat app start)
    @Query("DELETE FROM sitting_sessions WHERE date < :cutoffDate")
    suspend fun deleteOlderThan(cutoffDate: String)

    // ← TAMBAH: ambil entri terbaru untuk ditampilkan di home screen
    @Query("SELECT * FROM sitting_sessions ORDER BY timestamp DESC LIMIT 1")
    fun getLatestSession(): LiveData<SittingSession?>
}
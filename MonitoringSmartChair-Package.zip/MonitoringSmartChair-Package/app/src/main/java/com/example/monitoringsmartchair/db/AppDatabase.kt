// db/AppDatabase.kt
package com.example.monitoringsmartchair.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [SittingSession::class],
    version = 2,                // ← naik dari 1 ke 2
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun sessionDao(): SittingSessionDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        // Migrasi v1 → v2: tambah 3 kolom baru
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE sitting_sessions ADD COLUMN posture TEXT NOT NULL DEFAULT ''")
                database.execSQL("ALTER TABLE sitting_sessions ADD COLUMN confidence REAL NOT NULL DEFAULT 0.0")
                database.execSQL("ALTER TABLE sitting_sessions ADD COLUMN timestamp INTEGER NOT NULL DEFAULT 0")
            }
        }

        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "smart_chair.db"        // nama db tetap sama
                )
                    .addMigrations(MIGRATION_1_2)   // ← tambahkan migrasi
                    .build()
                    .also { INSTANCE = it }
            }
    }
}
package com.example.monitoringsmartchair

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.monitoringsmartchair.ble.BleManager
import com.example.monitoringsmartchair.databinding.ActivityBluetoothScanBinding

@SuppressLint("MissingPermission")
class BluetoothScanActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBluetoothScanBinding
    private lateinit var bleManager: BleManager
    private var bluetoothAdapter: BluetoothAdapter? = null
    private var isScanning = false
    private var scanCallback: ScanCallback? = null

    private val SCAN_TIMEOUT_MS = 15_000L

    private val enableBtLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (bluetoothAdapter?.isEnabled == true) {
            startScan()
        } else {
            showLoading(false)
            updateStatus("Bluetooth must be turned on to continue.")
        }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions.values.all { it }) {
            checkBluetoothEnabled()
        } else {
            showLoading(false)
            updateStatus("Bluetooth permission is required to continue.")
            Toast.makeText(this, "Please allow Bluetooth access.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBluetoothScanBinding.inflate(layoutInflater)
        setContentView(binding.root)

        bleManager       = BleManager.getInstance(this)
        bluetoothAdapter = (getSystemService(BLUETOOTH_SERVICE)
                as BluetoothManager).adapter

        binding.btnConnect.setOnClickListener {
            if (isScanning) {
                updateStatus("Scanning for SmartChair...")
            } else {
                checkPermissionsAndScan()
            }
        }

        bleManager.onConnectionChanged = { connected ->
            runOnUiThread {
                if (connected) {
                    updateStatus("Connected! Loading your dashboard...")
                    binding.btnConnect.isEnabled = false
                    startActivity(Intent(this, MainHomeActivity::class.java))
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
                    finish()
                } else {
                    isScanning = false
                    showLoading(false)
                    binding.btnConnect.isEnabled = true
                    updateStatus("Disconnected. Press Connect to retry.")
                }
            }
        }

        checkPermissionsAndScan()
    }

    @SuppressLint("InlinedApi")
    private fun checkPermissionsAndScan() {
        val perms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT
            )
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }

        val allGranted = perms.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }

        if (allGranted) checkBluetoothEnabled() else permissionLauncher.launch(perms)
    }

    private fun checkBluetoothEnabled() {
        if (bluetoothAdapter == null) {
            updateStatus("This device does not support Bluetooth.")
            return
        }
        if (bluetoothAdapter?.isEnabled == false) {
            enableBtLauncher.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
        } else {
            startScan()
        }
    }

    private fun startScan() {
        isScanning = true
        showLoading(true)
        updateStatus("Scanning for SmartChair...")

        binding.root.postDelayed({
            if (isScanning) {
                stopScan()
                updateStatus(
                    "Device not found.\n" +
                            "Make sure your SmartChair is powered on,\n" +
                            "then press Connect again."
                )
                binding.btnConnect.isEnabled = true
            }
        }, SCAN_TIMEOUT_MS)

        scanCallback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val name = result.device.name ?: return
                if (name.contains("SmartChair", ignoreCase = true)) {
                    stopScan()
                    runOnUiThread {
                        updateStatus("Device found. Connecting to $name...")
                    }
                    bleManager.connect(result.device)
                }
            }

            override fun onScanFailed(errorCode: Int) {
                isScanning = false
                runOnUiThread {
                    showLoading(false)
                    updateStatus("Scan failed (error $errorCode). Please try again.")
                }
            }
        }

        bluetoothAdapter?.bluetoothLeScanner?.startScan(scanCallback)
    }

    private fun stopScan() {
        bluetoothAdapter?.bluetoothLeScanner?.stopScan(scanCallback)
        scanCallback = null
        isScanning   = false
        runOnUiThread { showLoading(false) }
    }

    private fun showLoading(show: Boolean) {
        binding.progressBar.visibility = if (show) View.VISIBLE else View.GONE
        binding.btnConnect.isEnabled   = !show
    }

    private fun updateStatus(msg: String) {
        binding.tvStatus.text = msg
    }

    override fun onDestroy() {
        super.onDestroy()
        stopScan()
    }

    override fun onBackPressed() {
        super.onBackPressed()
        startActivity(Intent(this, SplashActivity::class.java))
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
        finish()
    }
}
// db/SittingSession.kt
package com.example.monitoringsmartchair.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sitting_sessions")
data class SittingSession(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val date: String,               // "yyyy-MM-dd"
    val posture: String,            // ← TAMBAH: label postur dari CNN
    val confidence: Float,          // ← TAMBAH: akurasi deteksi (0.0-1.0)
    val goodDurationSec: Long,      // total duduk BENAR (detik)
    val totalDurationSec: Long,     // total duduk keseluruhan
    val timestamp: Long             // ← TAMBAH: unix time dari RTC ESP32
)
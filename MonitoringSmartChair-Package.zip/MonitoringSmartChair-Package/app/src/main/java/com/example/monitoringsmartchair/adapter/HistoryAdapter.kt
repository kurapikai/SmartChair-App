// adapter/HistoryAdapter.kt
package com.example.monitoringsmartchair.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.monitoringsmartchair.databinding.ItemHistoryRowBinding
import com.example.monitoringsmartchair.db.SittingSession
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

class HistoryAdapter : ListAdapter<SittingSession, HistoryAdapter.ViewHolder>(DiffCb()) {

    inner class ViewHolder(
        private val b: ItemHistoryRowBinding
    ) : RecyclerView.ViewHolder(b.root) {
        fun bind(item: SittingSession) {
            val date = LocalDate.parse(item.date,
                DateTimeFormatter.ofPattern("yyyy-MM-dd"))
            val dayName = date.dayOfWeek
                .getDisplayName(TextStyle.SHORT, Locale.ENGLISH)
            b.tvDate.text = "$dayName, ${date.dayOfMonth} ${
                date.month.getDisplayName(TextStyle.SHORT, Locale.ENGLISH)
            } ${date.year}"
            // Tampilkan totalDurationSec bukan goodDurationSec
            b.tvDuration.text = item.totalDurationSec.toHHMM()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(ItemHistoryRowBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        ))

    override fun onBindViewHolder(holder: ViewHolder, position: Int) =
        holder.bind(getItem(position))

    private class DiffCb : DiffUtil.ItemCallback<SittingSession>() {
        override fun areItemsTheSame(a: SittingSession, b: SittingSession) =
            a.id == b.id
        // ← UBAH: bandingkan totalDurationSec secara eksplisit
        // agar DiffUtil mendeteksi perubahan saat update DB
        override fun areContentsTheSame(a: SittingSession, b: SittingSession) =
            a.id == b.id &&
                    a.date == b.date &&
                    a.totalDurationSec == b.totalDurationSec &&
                    a.goodDurationSec == b.goodDurationSec &&
                    a.posture == b.posture
    }
}

// Untuk history
fun Long.toHHMM(): String {
    val h = this / 3600
    val m = (this % 3600) / 60
    val s = this % 60
    return "${h}h ${m}m ${s}s"
}

// Untuk dashboard real-time
fun Long.toHHMMSS(): String {
    val h = this / 3600
    val m = (this % 3600) / 60
    val s = this % 60
    return "${h}h ${m}m ${s}s"
}
// PostureViewModel.kt
package com.example.monitoringsmartchair

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.monitoringsmartchair.db.AppDatabase
import com.example.monitoringsmartchair.db.SittingSession
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.text.SimpleDateFormat
import java.util.*

class PostureViewModel(app: Application) : AndroidViewModel(app) {

    private val dao = AppDatabase.getInstance(app).sessionDao()

    val history           = dao.getLast7Days()
    val currentPosture    = MutableLiveData("--")
    val sittingDuration   = MutableLiveData(0L)
    val currentConfidence = MutableLiveData(0f)

    private var timerJob           = null as Job?
    private var isGoodPosture      = false
    private var currentSessionSecs = 0L
    private var currentGoodSecs    = 0L

    // Akumulasi dari sesi-sesi sebelumnya hari ini
    // Di-load dari DB saat init ViewModel
    private var accumulatedSecs     = 0L
    private var accumulatedGoodSecs = 0L

    init {
        // Load akumulasi dari DB secara blocking saat ViewModel dibuat
        // Ini memastikan nilai sudah ada sebelum data BLE pertama masuk
        runBlocking {
            val today    = todayString()
            val existing = dao.getByDate(today)
            if (existing != null) {
                accumulatedSecs     = existing.totalDurationSec
                accumulatedGoodSecs = existing.goodDurationSec
                android.util.Log.d("ViewModel", "Init loaded: total=$accumulatedSecs, good=$accumulatedGoodSecs")
            } else {
                android.util.Log.d("ViewModel", "Init: no existing data for today")
            }
        }
    }

    fun onPostureReceived(
        posture: String,
        confidence: Float,
        duration: Long,
        timestamp: Long
    ) {
        currentPosture.postValue(posture)
        currentConfidence.postValue(confidence)
        isGoodPosture = (posture == "duduk_tegak")

        if (posture != "kursi_kosong") {
            currentSessionSecs = duration
            sittingDuration.postValue(currentSessionSecs)
            saveToDb()
        } else {
            if (currentSessionSecs > 0L) {
                // Tambahkan sesi yang baru selesai ke akumulasi
                accumulatedSecs     += currentSessionSecs
                accumulatedGoodSecs += currentGoodSecs

                android.util.Log.d("ViewModel",
                    "Sesi selesai: +$currentSessionSecs detik, accumulated=$accumulatedSecs")

                saveAccumulatedToDb()

                currentSessionSecs = 0L
                currentGoodSecs    = 0L
            }
            sittingDuration.postValue(0L)
        }
    }

    fun startTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1_000)
                if (isGoodPosture) currentGoodSecs++
            }
        }
    }

    fun stopTimer() {
        timerJob?.cancel()
        if (currentSessionSecs > 0L) {
            accumulatedSecs     += currentSessionSecs
            accumulatedGoodSecs += currentGoodSecs
        }
        saveAccumulatedToDb()
    }

    fun saveNow() {
        saveToDb()
    }

    fun deleteOldData() = viewModelScope.launch {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -7)
        dao.deleteOlderThan(sdf.format(cal.time))
    }

    // Simpan akumulasi + sesi aktif (dipanggil tiap postur aktif masuk)
    private fun saveToDb() = viewModelScope.launch {
        if (currentSessionSecs == 0L) return@launch

        val today          = todayString()
        val lastPosture    = currentPosture.value ?: "--"
        val lastConfidence = currentConfidence.value ?: 0f
        val lastTimestamp  = System.currentTimeMillis() / 1000
        val totalToSave    = accumulatedSecs + currentSessionSecs
        val goodToSave     = accumulatedGoodSecs + currentGoodSecs

        android.util.Log.d("ViewModel",
            "saveToDb: accumulated=$accumulatedSecs + current=$currentSessionSecs = $totalToSave")

        val existing = dao.getByDate(today)
        if (existing != null) {
            dao.update(existing.copy(
                posture          = lastPosture,
                confidence       = lastConfidence,
                timestamp        = lastTimestamp,
                goodDurationSec  = goodToSave,
                totalDurationSec = totalToSave
            ))
        } else {
            dao.insert(SittingSession(
                date             = today,
                posture          = lastPosture,
                confidence       = lastConfidence,
                timestamp        = lastTimestamp,
                goodDurationSec  = goodToSave,
                totalDurationSec = totalToSave
            ))
        }
    }

    // Simpan akumulasi final (saat sesi selesai / app ditutup)
    private fun saveAccumulatedToDb() = viewModelScope.launch {
        if (accumulatedSecs == 0L) return@launch

        val today          = todayString()
        val lastPosture    = currentPosture.value ?: "--"
        val lastConfidence = currentConfidence.value ?: 0f
        val lastTimestamp  = System.currentTimeMillis() / 1000

        android.util.Log.d("ViewModel",
            "saveAccumulated: total=$accumulatedSecs, good=$accumulatedGoodSecs")

        val existing = dao.getByDate(today)
        if (existing != null) {
            dao.update(existing.copy(
                posture          = lastPosture,
                confidence       = lastConfidence,
                timestamp        = lastTimestamp,
                goodDurationSec  = accumulatedGoodSecs,
                totalDurationSec = accumulatedSecs
            ))
        } else {
            dao.insert(SittingSession(
                date             = today,
                posture          = lastPosture,
                confidence       = lastConfidence,
                timestamp        = lastTimestamp,
                goodDurationSec  = accumulatedGoodSecs,
                totalDurationSec = accumulatedSecs
            ))
        }
    }

    private fun todayString(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
    }
}

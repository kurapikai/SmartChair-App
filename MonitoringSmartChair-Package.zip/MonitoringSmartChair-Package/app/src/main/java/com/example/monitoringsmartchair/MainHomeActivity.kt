package com.example.monitoringsmartchair

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.monitoringsmartchair.adapter.HistoryAdapter
import com.example.monitoringsmartchair.adapter.toHHMMSS
import com.example.monitoringsmartchair.ble.BleManager
import com.example.monitoringsmartchair.databinding.ActivityMainHomeBinding

@SuppressLint("MissingPermission")
class MainHomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainHomeBinding
    private val viewModel: PostureViewModel by viewModels()
    private lateinit var bleManager: BleManager
    private lateinit var historyAdapter: HistoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupBle()
        observeViewModel()
        viewModel.startTimer()
        viewModel.deleteOldData()
    }

    private fun setupRecyclerView() {
        historyAdapter = HistoryAdapter()
        binding.rvHistory.layoutManager = LinearLayoutManager(this)
        binding.rvHistory.adapter = historyAdapter
    }

    private fun setupBle() {
        bleManager = BleManager.getInstance(this)

        bleManager.onPostureReceived = { posture, confidence, duration, timestamp ->
            viewModel.onPostureReceived(posture, confidence, duration, timestamp)
        }

        bleManager.onConnectionChanged = { connected ->
            runOnUiThread {
                if (connected) {
                    binding.tvConnectionStatus.text = "● Connected"
                    binding.tvConnectionStatus.setTextColor(getColor(R.color.dark_green))
                } else {
                    binding.tvConnectionStatus.text = "● Disconnected — returning to scan page..."
                    binding.tvConnectionStatus.setTextColor(getColor(R.color.notif_red))
                    binding.tvCurrentPosture.text = "--"
                    binding.tvConfidence.text     = "Accuracy: --"
                    binding.tvDuration.text       = "0h 0m 0s"

                    binding.root.postDelayed({
                        startActivity(Intent(this, BluetoothScanActivity::class.java))
                        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
                        finish()
                    }, 3000)
                }
            }
        }

        runOnUiThread {
            if (bleManager.isConnected) {
                binding.tvConnectionStatus.text = "● Connected"
                binding.tvConnectionStatus.setTextColor(getColor(R.color.dark_green))
            } else {
                binding.tvConnectionStatus.text = "● Disconnected"
                binding.tvConnectionStatus.setTextColor(getColor(R.color.notif_red))
            }
        }
    }

    // Terjemahan label CNN ke English untuk ditampilkan di UI
    private fun translatePosture(posture: String): String {
        return when (posture) {
            "duduk_tegak"       -> "Upright"
            "membungkuk"        -> "Slouching"
            "silang_kanan"      -> "Legs Crossed Right"
            "silang_kiri"       -> "Legs Crossed Left"
            "miring_kanan"      -> "Leaning Right"
            "miring_kiri"       -> "Leaning Left"
            "kursi_kosong"      -> "Unoccupied"
            else                -> posture
        }
    }

    private fun observeViewModel() {
        viewModel.currentPosture.observe(this) { posture ->
            // Tampilkan label dalam English
            binding.tvCurrentPosture.text = translatePosture(posture)

            // Kondisi tetap pakai label asli dari ESP32 (huruf kecil)
            when (posture) {
                "duduk_tegak" -> {
                    hideBanner()
                    binding.tvCurrentPosture.setTextColor(getColor(R.color.dark_green))
                }
                "kursi_kosong", "--" -> {
                    hideBanner()
                    binding.tvCurrentPosture.setTextColor(getColor(R.color.text_primary))
                }
                else -> {
                    binding.tvCurrentPosture.setTextColor(getColor(R.color.notif_red))
                    showBanner(
                        title     = "Poor Posture Detected",
                        subtitle  = "Please correct your sitting posture.",
                        isWarning = true
                    )
                }
            }
        }

        viewModel.currentConfidence.observe(this) { confidence ->
            val persen = (confidence * 100).toInt()
            binding.tvConfidence.text = "Accuracy: $persen%"
        }

        viewModel.sittingDuration.observe(this) { secs ->
            binding.tvDuration.text = secs.toHHMMSS()
            if (secs > 0 && secs % 3600L == 0L) {
                showBanner(
                    title     = "Extended Sitting Detected",
                    subtitle  = "Consider taking a short break and stretching.",
                    isWarning = false
                )
            }
        }

        viewModel.history.observe(this) { sessions ->
            historyAdapter.submitList(sessions)
        }
    }

    private fun showBanner(title: String, subtitle: String, isWarning: Boolean) {
        binding.layoutBanner.visibility = View.VISIBLE
        binding.tvBannerTitle.text      = title
        binding.tvBannerSubtitle.text   = subtitle
        binding.layoutBanner.setBackgroundColor(
            if (isWarning) getColor(R.color.notif_red_bg)
            else getColor(R.color.notif_yellow_bg)
        )
        binding.ivBannerIcon.setImageResource(
            if (isWarning) R.drawable.ic_warning
            else R.drawable.ic_clock
        )
        if (isWarning) vibrate(300) else vibrate(600)
        binding.layoutBanner.postDelayed({ hideBanner() }, 5000)
    }

    private fun hideBanner() {
        binding.layoutBanner.visibility = View.GONE
    }

    private fun vibrate(durationMs: Long = 300) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vm.defaultVibrator.vibrate(
                VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE)
            )
        } else {
            @Suppress("DEPRECATION")
            val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
            @Suppress("DEPRECATION")
            v.vibrate(durationMs)
        }
    }

    override fun onStop() {
        super.onStop()
        viewModel.saveNow()  // ← simpan segera saat app di-minimize atau ditutup
    }

    override fun onDestroy() {
        super.onDestroy()
        viewModel.stopTimer()
    }

    override fun onBackPressed() {
        super.onBackPressed()
        startActivity(Intent(this, BluetoothScanActivity::class.java))
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
        finish()
    }
}
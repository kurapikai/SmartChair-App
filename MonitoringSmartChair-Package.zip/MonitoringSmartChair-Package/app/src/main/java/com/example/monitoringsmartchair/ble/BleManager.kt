package com.example.monitoringsmartchair.ble

import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.Context
import android.os.Build
import org.json.JSONObject
import java.util.UUID

@SuppressLint("MissingPermission")
class BleManager private constructor(private val context: Context) {

    companion object {
        val SERVICE_UUID: UUID =
            UUID.fromString("12345678-1234-1234-1234-123456789abc")
        val POSTURE_CHAR_UUID: UUID =
            UUID.fromString("12345678-1234-1234-1234-123456789def")

        @Volatile private var INSTANCE: BleManager? = null

        fun getInstance(context: Context): BleManager {
            return INSTANCE ?: synchronized(this) {
                BleManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }

    var onPostureReceived: ((posture: String, confidence: Float, duration: Long, timestamp: Long) -> Unit)? = null
    var onConnectionChanged: ((Boolean) -> Unit)? = null

    private var gatt: BluetoothGatt? = null
    var isConnected = false
        private set

    fun connect(device: BluetoothDevice) {
        gatt = device.connectGatt(context, false, gattCallback)
    }

    fun disconnect() {
        gatt?.disconnect()
        gatt?.close()
        gatt = null
        isConnected = false
    }

    private fun parseAndDeliver(raw: String) {
        try {
            val json       = JSONObject(raw)
            val posture    = json.getString("posture")
            val confidence = json.getDouble("confidence").toFloat()
            val duration   = json.getLong("duration")
            val timestamp  = json.getLong("ts")
            android.util.Log.d("BleManager", "Data masuk: $raw")
            onPostureReceived?.invoke(posture, confidence, duration, timestamp)
        } catch (e: Exception) {
            android.util.Log.e("BleManager", "Parse error: ${e.message}")
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {

        override fun onConnectionStateChange(
            g: BluetoothGatt, status: Int, newState: Int
        ) {
            isConnected = newState == BluetoothProfile.STATE_CONNECTED
            onConnectionChanged?.invoke(isConnected)
            if (isConnected) {
                g.requestMtu(512)  // request MTU besar dulu sebelum discover
            }
        }

        // MTU berhasil diubah → baru discover services
        override fun onMtuChanged(g: BluetoothGatt, mtu: Int, status: Int) {
            android.util.Log.d("BleManager", "MTU changed to: $mtu")
            g.discoverServices()
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            android.util.Log.d("BleManager", "onServicesDiscovered status: $status")

            val service = g.getService(SERVICE_UUID)
            if (service == null) {
                android.util.Log.e("BleManager", "SERVICE TIDAK DITEMUKAN!")
                return
            }

            val characteristic = service.getCharacteristic(POSTURE_CHAR_UUID)
            if (characteristic == null) {
                android.util.Log.e("BleManager", "CHARACTERISTIC TIDAK DITEMUKAN!")
                return
            }

            android.util.Log.d("BleManager", "Characteristic ditemukan, set notification...")
            g.setCharacteristicNotification(characteristic, true)

            val descriptor = characteristic.getDescriptor(
                UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
            )
            if (descriptor == null) {
                android.util.Log.e("BleManager", "DESCRIPTOR TIDAK DITEMUKAN!")
                return
            }

            android.util.Log.d("BleManager", "Descriptor ditemukan, write notification value...")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val result = g.writeDescriptor(descriptor, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
                android.util.Log.d("BleManager", "writeDescriptor result: $result")
            } else {
                @Suppress("DEPRECATION")
                descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                @Suppress("DEPRECATION")
                val result = g.writeDescriptor(descriptor)
                android.util.Log.d("BleManager", "writeDescriptor result: $result")
            }
        }

        @Deprecated("Deprecated in Java")
        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(
            g: BluetoothGatt,
            c: BluetoothGattCharacteristic
        ) {
            val raw = c.value?.toString(Charsets.UTF_8) ?: return
            parseAndDeliver(raw.trim())
        }

        override fun onCharacteristicChanged(
            g: BluetoothGatt,
            c: BluetoothGattCharacteristic,
            value: ByteArray
        ) {
            parseAndDeliver(String(value, Charsets.UTF_8).trim())
        }
    }
}